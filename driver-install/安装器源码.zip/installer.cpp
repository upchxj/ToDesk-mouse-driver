#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>
#include <setupapi.h>
#include <cfgmgr32.h>
#include <bcrypt.h>
#include <wintrust.h>
#include <softpub.h>
#include <sddl.h>
#include <shlobj.h>
#include <shellapi.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <filesystem>
#include <string>
#include <vector>
#include <cstdio>
#include <stdexcept>
#include <algorithm>
#include "payloads.h"
#include "todesk_mouse.h"

namespace fs=std::filesystem;
namespace {
constexpr wchar_t title[]=L"ToDesk 本机鼠标 · 离线安装";
constexpr wchar_t hardware_id[]=L"root\\TodeskVhid";
constexpr int success=0, restart=3010, unsupported=10, access_error=11,
    damaged=12, signature_error=13, device_error=14, install_error=15,
    probe_error=16, busy_error=17, timeout_error=18;
struct Failure { int code; std::wstring message; };
struct Handle {
    HANDLE h=nullptr;
    explicit Handle(HANDLE value=nullptr):h(value){}
    ~Handle(){ if(h && h!=INVALID_HANDLE_VALUE) CloseHandle(h); }
    Handle(const Handle&)=delete;
    Handle& operator=(const Handle&)=delete;
};
fs::path log_path, deployment;
FILE* log_file=nullptr;
bool quiet=false;

std::string utf8(const std::wstring& value) {
    if(value.empty())return {};
    int count=WideCharToMultiByte(CP_UTF8,0,value.data(),static_cast<int>(value.size()),nullptr,0,nullptr,nullptr);
    std::string out(static_cast<size_t>(count),0);
    WideCharToMultiByte(CP_UTF8,0,value.data(),static_cast<int>(value.size()),out.data(),count,nullptr,nullptr);
    return out;
}
void log(const std::wstring& value) {
    std::string line=utf8(value)+"\r\n";
    std::fwrite(line.data(),1,line.size(),stdout); std::fflush(stdout);
    if(log_file){std::fwrite(line.data(),1,line.size(),log_file);std::fflush(log_file);}
}
std::wstring windows_error(DWORD code=GetLastError()) {
    wchar_t* text=nullptr;
    FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr,code,0,reinterpret_cast<LPWSTR>(&text),0,nullptr);
    std::wstring result=std::to_wstring(code)+L": "+(text?text:L"未知系统错误");
    if(text)LocalFree(text);
    return result;
}
[[noreturn]] void fail(int code,const std::wstring& text){throw Failure{code,text};}

std::wstring guid() {
    GUID id{};
    if(FAILED(CoCreateGuid(&id)))fail(access_error,L"无法生成安装会话标识。");
    wchar_t buffer[40]{}; StringFromGUID2(id,buffer,40);
    return buffer;
}
bool elevated() {
    HANDLE raw=nullptr;
    if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&raw))return false;
    Handle token(raw); TOKEN_ELEVATION result{}; DWORD bytes=0;
    return GetTokenInformation(token.h,TokenElevation,&result,sizeof(result),&bytes) && result.TokenIsElevated;
}
fs::path known(REFKNOWNFOLDERID id) {
    PWSTR value=nullptr;
    HRESULT hr=SHGetKnownFolderPath(id,0,nullptr,&value);
    if(FAILED(hr))fail(access_error,L"无法取得 Windows 标准目录。");
    fs::path result(value); CoTaskMemFree(value); return result;
}
fs::path system_dir() {
    wchar_t value[MAX_PATH]{};
    if(!GetSystemDirectoryW(value,MAX_PATH))fail(access_error,L"无法取得系统目录。");
    return value;
}
void reject_reparse(const fs::path& path) {
    for(fs::path p=path;!p.empty();) {
        DWORD attr=GetFileAttributesW(p.c_str());
        if(attr!=INVALID_FILE_ATTRIBUTES && (attr&FILE_ATTRIBUTE_REPARSE_POINT))
            fail(access_error,L"安装目录含重解析点/链接，停止以防写入错误位置："+p.wstring());
        fs::path parent=p.parent_path();
        if(parent==p)break;
        p=parent;
    }
}
void create_secure_dir(const fs::path& path) {
    reject_reparse(path);
    PSECURITY_DESCRIPTOR sd=nullptr;
    if(!ConvertStringSecurityDescriptorToSecurityDescriptorW(
        L"D:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;GRGX;;;BU)",SDDL_REVISION_1,&sd,nullptr))
        fail(access_error,L"无法创建安装目录权限。");
    SECURITY_ATTRIBUTES sa{sizeof(sa),sd,FALSE};
    BOOL ok=CreateDirectoryW(path.c_str(),&sa); DWORD error=GetLastError(); LocalFree(sd);
    if(!ok)fail(access_error,L"无法创建新的安装目录："+path.wstring()+L"\n"+windows_error(error));
}
void start_log(bool check_only) {
    fs::path parent=known(check_only?FOLDERID_LocalAppData:FOLDERID_ProgramFiles);
    // A new, unpredictable directory; never execute files from a reused writable folder.
    deployment=parent/(L"ToDeskMouse-"+guid());
    if(check_only) {
        reject_reparse(deployment);
        if(!CreateDirectoryW(deployment.c_str(),nullptr))fail(access_error,L"无法创建检测目录。");
    } else create_secure_dir(deployment);
    log_path=deployment/L"install.log";
    if(_wfopen_s(&log_file,log_path.c_str(),L"wb")!=0 || !log_file)
        fail(access_error,L"无法创建安装日志。");
    SYSTEMTIME t{};GetLocalTime(&t);
    wchar_t date[80]{};swprintf_s(date,L"%04u-%02u-%02u %02u:%02u:%02u",t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond);
    log(L"ToDeskMouseSetup 1.0.0 | "+std::wstring(date));
    log(L"目录："+deployment.wstring());
    log(check_only?L"模式：仅检测，不安装/修改驱动。":L"模式：离线安装；不下载任何组件。");
}

std::string digest(const BYTE* data,DWORD bytes) {
    BYTE hash[32]{};
    NTSTATUS status=BCryptHash(BCRYPT_SHA256_ALG_HANDLE,nullptr,0,const_cast<PUCHAR>(data),bytes,hash,sizeof(hash));
    if(status<0)fail(damaged,L"系统 SHA256 校验失败。");
    static constexpr char hex[]="0123456789abcdef";
    std::string result;
    for(BYTE b:hash){result.push_back(hex[b>>4]);result.push_back(hex[b&15]);}
    return result;
}
std::vector<BYTE> read_file(const fs::path& path) {
    Handle file(CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,nullptr));
    if(file.h==INVALID_HANDLE_VALUE)fail(access_error,L"无法读取文件："+path.wstring()+L"\n"+windows_error());
    LARGE_INTEGER size{};
    if(!GetFileSizeEx(file.h,&size) || size.QuadPart<=0 || size.QuadPart>64*1024*1024)
        fail(damaged,L"文件大小异常："+path.wstring());
    std::vector<BYTE> data(static_cast<size_t>(size.QuadPart)); DWORD got=0;
    if(!ReadFile(file.h,data.data(),static_cast<DWORD>(data.size()),&got,nullptr) || got!=data.size())
        fail(access_error,L"文件读取不完整："+path.wstring());
    return data;
}
void write_file(const fs::path& path,const BYTE* data,DWORD bytes) {
    reject_reparse(path);
    Handle file(CreateFileW(path.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr));
    if(file.h==INVALID_HANDLE_VALUE)fail(access_error,L"无法写入文件："+path.wstring()+L"\n"+windows_error());
    DWORD written=0;
    if(!WriteFile(file.h,data,bytes,&written,nullptr) || written!=bytes || !FlushFileBuffers(file.h))
        fail(access_error,L"文件写入失败，检查磁盘空间或安全软件："+path.wstring());
}
void text_file(const fs::path& path,const std::string& data){write_file(path,reinterpret_cast<const BYTE*>(data.data()),static_cast<DWORD>(data.size()));}
void unpack() {
    ULARGE_INTEGER available{};
    if(!GetDiskFreeSpaceExW(deployment.c_str(),&available,nullptr,nullptr) || available.QuadPart<100ull*1024*1024)
        fail(access_error,L"安装盘可用空间不足 100 MB，或无法读取磁盘状态。");
    fs::create_directory(deployment/L"driver");
    fs::create_directory(deployment/L"app");
    fs::create_directory(deployment/L"app"/L"x64");
    fs::create_directory(deployment/L"app"/L"x86");
    for(const auto& item:payloads) {
        HRSRC resource=FindResourceW(nullptr,MAKEINTRESOURCEW(item.id),MAKEINTRESOURCEW(10));
        if(!resource)fail(damaged,L"安装器内嵌文件缺失，请重新复制安装器。");
        DWORD size=SizeofResource(nullptr,resource);
        HGLOBAL loaded=LoadResource(nullptr,resource);
        const auto* bytes=static_cast<const BYTE*>(LockResource(loaded));
        if(!bytes || !size || digest(bytes,size)!=item.sha256)fail(damaged,L"内嵌文件校验失败："+std::wstring(item.path));
        fs::path destination=deployment/item.path;
        write_file(destination,bytes,size);
        const auto saved=read_file(destination);
        if(digest(saved.data(),static_cast<DWORD>(saved.size()))!=item.sha256)
            fail(damaged,L"释放后的文件校验失败："+destination.wstring());
        log(L"SHA256 OK: "+std::wstring(item.path));
    }
}
void verify_signature(const fs::path& path) {
    WINTRUST_FILE_INFO file{};file.cbStruct=sizeof(file);file.pcwszFilePath=path.c_str();
    WINTRUST_DATA data{};data.cbStruct=sizeof(data);data.dwUIChoice=WTD_UI_NONE;
    data.fdwRevocationChecks=WTD_REVOKE_NONE;data.dwUnionChoice=WTD_CHOICE_FILE;data.pFile=&file;
    data.dwStateAction=WTD_STATEACTION_VERIFY;
    data.dwProvFlags=WTD_CACHE_ONLY_URL_RETRIEVAL|WTD_REVOCATION_CHECK_NONE;
    GUID action=WINTRUST_ACTION_GENERIC_VERIFY_V2;
    LONG result=WinVerifyTrust(nullptr,&action,&data);
    data.dwStateAction=WTD_STATEACTION_CLOSE;WinVerifyTrust(nullptr,&action,&data);
    wchar_t code[32]{};swprintf_s(code,L"0x%08lX",static_cast<unsigned long>(result));
    log(L"离线签名验证 "+path.filename().wstring()+L": "+code);
    if(result!=ERROR_SUCCESS)
        fail(signature_error,L"Windows 离线签名验证失败（"+std::wstring(code)+L"）。\n"
             L"请检查系统时间、证书信任和系统更新。此安装器不会下载证书或关闭签名保护。\n文件："+path.wstring());
}
void platform_check() {
    SYSTEM_INFO info{};GetNativeSystemInfo(&info);
    if(info.wProcessorArchitecture!=PROCESSOR_ARCHITECTURE_AMD64)
        fail(unsupported,L"本驱动包仅支持 Intel/AMD x64 Windows，不支持 ARM64 或 32 位 Windows。");
    using RtlVersion=NTSTATUS(WINAPI*)(PRTL_OSVERSIONINFOW);
    auto version=reinterpret_cast<RtlVersion>(GetProcAddress(GetModuleHandleW(L"ntdll.dll"),"RtlGetVersion"));
    RTL_OSVERSIONINFOW os{};os.dwOSVersionInfoSize=sizeof(os);
    if(!version || version(&os)<0 || os.dwMajorVersion<10)
        fail(unsupported,L"此部署包要求 Windows 10/11 x64；旧系统未适配。");
    log(L"Windows "+std::to_wstring(os.dwMajorVersion)+L" build "+std::to_wstring(os.dwBuildNumber));
    for(const wchar_t* name:{L"drivers\\WUDFRd.sys",L"drivers\\mshidumdf.sys"})
        if(!fs::is_regular_file(system_dir()/name))fail(unsupported,L"系统缺少 UMDF/HID 组件："+std::wstring(name)+L"。请修复/更新 Windows 后重试。");
}

void check_other_installers() {
    Handle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0));
    if(snapshot.h==INVALID_HANDLE_VALUE)fail(busy_error,L"无法检查正在运行的安装工具，请重试。");
    PROCESSENTRY32W process{};process.dwSize=sizeof(process);
    if(!Process32FirstW(snapshot.h,&process))fail(busy_error,L"无法读取进程列表。");
    do {
        if(_wcsicmp(process.szExeFile,L"devcon.exe")==0)
            fail(busy_error,L"发现 devcon.exe 仍在运行（PID "+std::to_wstring(process.th32ProcessID)+
                L"）。可能是先前未完成的设备安装，请确认结束后再重试。不会强制终止该进程。");
    }while(Process32NextW(snapshot.h,&process));
}

struct Node {std::wstring id;ULONG status=0,problem=0;bool present=false;};
std::vector<Node> legacy_nodes() {
    HDEVINFO set=SetupDiGetClassDevsW(nullptr,nullptr,nullptr,DIGCF_ALLCLASSES);
    if(set==INVALID_HANDLE_VALUE)fail(device_error,L"无法枚举 PnP 设备："+windows_error());
    struct Cleanup{HDEVINFO set;~Cleanup(){SetupDiDestroyDeviceInfoList(set);}} cleanup{set};
    std::vector<Node> nodes;
    for(DWORD index=0;;++index) {
        SP_DEVINFO_DATA info{};info.cbSize=sizeof(info);
        if(!SetupDiEnumDeviceInfo(set,index,&info)) {
            if(GetLastError()!=ERROR_NO_MORE_ITEMS)fail(device_error,L"设备枚举异常终止。");
            break;
        }
        wchar_t ids[8192]{};DWORD type=0;
        if(!SetupDiGetDeviceRegistryPropertyW(set,&info,SPDRP_HARDWAREID,&type,reinterpret_cast<PBYTE>(ids),sizeof(ids)-sizeof(wchar_t)*2,nullptr))continue;
        if(type!=REG_MULTI_SZ)continue;
        bool match=false;
        for(const wchar_t* p=ids;*p;p+=wcslen(p)+1)if(_wcsicmp(p,hardware_id)==0)match=true;
        if(!match)continue;
        wchar_t instance[MAX_DEVICE_ID_LEN]{};
        if(!SetupDiGetDeviceInstanceIdW(set,&info,instance,MAX_DEVICE_ID_LEN,nullptr))
            fail(device_error,L"无法读取旧版设备实例标识。");
        Node node;node.id=instance;
        CONFIGRET cr=CM_Get_DevNode_Status(&node.status,&node.problem,info.DevInst,0);
        node.present=cr==CR_SUCCESS && node.problem!=CM_PROB_PHANTOM;
        log(L"设备 "+node.id+L" present="+std::to_wstring(node.present)+L" problem="+std::to_wstring(node.problem)+L" status="+std::to_wstring(node.status));
        nodes.push_back(node);
    }
    return nodes;
}
bool probe(bool verbose=true) {
    TdMouse mouse=td_open();
    const char* raw=td_diagnostic();
    if(verbose && raw) {
        int length=MultiByteToWideChar(CP_UTF8,0,raw,-1,nullptr,0);
        if(length>0){std::wstring value(static_cast<size_t>(length),0);MultiByteToWideChar(CP_UTF8,0,raw,-1,value.data(),length);log(value.c_str());}
    }
    if(mouse){td_close(mouse);return true;}
    return false;
}
std::wstring quote(const std::wstring& s) {
    if(s.find(L'"')!=std::wstring::npos)fail(access_error,L"命令路径包含无效引号。");
    return L"\""+s+L"\"";
}
DWORD run_tool(const fs::path& exe,const std::wstring& args,const wchar_t* output_name,DWORD timeout_ms=120000) {
    fs::path output=deployment/output_name;
    SECURITY_ATTRIBUTES sa{sizeof(sa),nullptr,TRUE};
    Handle out(CreateFileW(output.c_str(),GENERIC_WRITE,FILE_SHARE_READ,&sa,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr));
    Handle input(CreateFileW(L"NUL",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_EXISTING,0,nullptr));
    if(out.h==INVALID_HANDLE_VALUE || input.h==INVALID_HANDLE_VALUE)fail(access_error,L"无法创建安装进程日志。");
    SIZE_T bytes=0;InitializeProcThreadAttributeList(nullptr,1,0,&bytes);
    std::vector<BYTE> storage(bytes);
    auto attributes=reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(storage.data());
    if(!InitializeProcThreadAttributeList(attributes,1,0,&bytes))fail(access_error,L"无法初始化进程属性。");
    struct Cleanup{LPPROC_THREAD_ATTRIBUTE_LIST p;~Cleanup(){DeleteProcThreadAttributeList(p);}} cleanup{attributes};
    HANDLE inherited[]={out.h,input.h};
    if(!UpdateProcThreadAttribute(attributes,0,PROC_THREAD_ATTRIBUTE_HANDLE_LIST,inherited,sizeof(inherited),nullptr,nullptr))
        fail(access_error,L"无法限制子进程继承句柄。");
    STARTUPINFOEXW si{};si.StartupInfo.cb=sizeof(si);si.lpAttributeList=attributes;
    si.StartupInfo.dwFlags=STARTF_USESTDHANDLES|STARTF_USESHOWWINDOW;si.StartupInfo.wShowWindow=SW_HIDE;
    si.StartupInfo.hStdInput=input.h;si.StartupInfo.hStdOutput=out.h;si.StartupInfo.hStdError=out.h;
    std::wstring command=quote(exe.wstring())+L" "+args;
    log(L"执行："+command);
    PROCESS_INFORMATION pi{};
    if(!CreateProcessW(exe.c_str(),command.data(),nullptr,nullptr,TRUE,CREATE_NO_WINDOW|EXTENDED_STARTUPINFO_PRESENT,
                       nullptr,exe.parent_path().c_str(),&si.StartupInfo,&pi))
        fail(install_error,L"无法启动安装/测试工具："+windows_error()+L"\n检查安全软件拦截记录。");
    Handle process(pi.hProcess),thread(pi.hThread);
    const ULONGLONG end=GetTickCount64()+timeout_ms;
    for(;;) {
        DWORD wait=WaitForSingleObject(process.h,1000);
        if(wait==WAIT_OBJECT_0)break;
        if(wait==WAIT_FAILED)fail(install_error,L"等待工具失败："+windows_error());
        if(GetTickCount64()>=end) {
            // Do not terminate an in-progress system driver transaction.
            fail(timeout_error,L"工具运行超过两分钟，尚未确认完成；未强制终止系统安装。\n"
                 L"请查看任务管理器和工具日志，确认进程结束后再重试，不要重复点击安装。\n"+output.wstring());
        }
    }
    DWORD code=0;
    if(!GetExitCodeProcess(process.h,&code))fail(install_error,L"无法取得工具退出码。");
    log(L"工具退出码："+std::to_wstring(code)+L"；输出："+output.wstring());
    return code;
}
void record_nodes(const std::vector<Node>& before,const std::vector<Node>& after) {
    std::string report="This session only. Do not delete unrelated devices.\r\n";
    for(const auto& n:after) {
        bool created=std::none_of(before.begin(),before.end(),[&](const Node& b){return _wcsicmp(b.id.c_str(),n.id.c_str())==0;});
        report+=(created?"CREATED ":"EXISTING ")+utf8(n.id)+" problem="+std::to_string(n.problem)+"\r\n";
    }
    text_file(deployment/L"device-receipt.txt",report);
}
void diagnostic_logs() noexcept {
    try {
        wchar_t windows[MAX_PATH]{};GetWindowsDirectoryW(windows,MAX_PATH);
        fs::path setup=fs::path(windows)/L"inf"/L"setupapi.dev.log";
        // Save only a bounded tail of the system device installation log.
        Handle src(CreateFileW(setup.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,0,nullptr));
        if(src.h!=INVALID_HANDLE_VALUE) {
            LARGE_INTEGER size{};GetFileSizeEx(src.h,&size);
            LARGE_INTEGER offset{};offset.QuadPart=std::max<LONGLONG>(0,size.QuadPart-512*1024);
            SetFilePointerEx(src.h,offset,nullptr,FILE_BEGIN);
            std::vector<BYTE> buffer(512*1024);DWORD count=0;
            if(ReadFile(src.h,buffer.data(),static_cast<DWORD>(buffer.size()),&count,nullptr) && count)
                write_file(deployment/L"setupapi-tail.log",buffer.data(),count);
        }
    }catch(...){}
}
void create_shortcut() {
    HRESULT init=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);
    if(FAILED(init)){log(L"快捷方式创建跳过：COM 初始化失败。");return;}
    IShellLinkW* link=nullptr;
    HRESULT hr=CoCreateInstance(CLSID_ShellLink,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&link));
    if(SUCCEEDED(hr)) {
        fs::path exe=deployment/L"app"/L"x64"/L"mouse_test.exe";
        link->SetPath(exe.c_str());link->SetWorkingDirectory(exe.parent_path().c_str());
        link->SetDescription(L"ToDesk 本机鼠标测试（旧版 VHID）");
        IPersistFile* persist=nullptr;
        hr=link->QueryInterface(IID_PPV_ARGS(&persist));
        if(SUCCEEDED(hr)) {
            try {
                fs::path shortcut=known(FOLDERID_PublicDesktop)/L"ToDesk 本机鼠标测试.lnk";
                if(fs::exists(shortcut))shortcut=known(FOLDERID_PublicDesktop)/(L"ToDesk 本机鼠标测试 "+guid()+L".lnk");
                hr=persist->Save(shortcut.c_str(),TRUE);
            }catch(...){hr=E_FAIL;}
            persist->Release();
        }
        link->Release();
    }
    CoUninitialize();
    log(SUCCEEDED(hr)?L"已创建公共桌面测试程序快捷方式。":L"桌面快捷方式未创建，可直接运行安装目录中的 app\\x64\\mouse_test.exe。");
}
void installed_instructions() {
    text_file(deployment/L"使用说明.txt",utf8(
        L"ToDesk 本机鼠标离线部署\r\n\r\n运行 app\\x64\\mouse_test.exe 打开测试窗口。\r\n"
        L"集成文件：app\\x64\\todesk_mouse.dll 或 app\\x86\\todesk_mouse.dll，按进程位数选择。\r\n"
        L"已安装驱动由 Windows 管理；不要把 driver\\TodeskVhid.dll 当应用 DLL 加载。\r\n"
        L"安装日志：install.log；工具日志：devcon-install.log / devcon-update.log / probe.log。\r\n"
        L"如提示重启，请先重启，再运行 mouse_test.exe --probe 检测。\r\n"
        L"此安装器不会关闭驱动签名、内存完整性或安全软件；不支持 ARM64 / 32 位 Windows。\r\n"
        L"移除本次新建设备：核对 device-receipt.txt 中 CREATED 实例，\r\n"
        L"在管理员终端执行 driver\\devcon.exe remove \"@实例ID\"。\r\n"
        L"EXISTING 设备不属于本次新建，请勿按此说明移除。驱动仓库保留。\r\n"));
}
int execute(bool check_only) {
    platform_check();
    if(!check_only)check_other_installers();
    unpack();
    verify_signature(deployment/L"driver"/L"TodeskVhid.dll");
    verify_signature(deployment/L"driver"/L"todeskvhid.cat");
    auto before=legacy_nodes();
    bool usable=probe();
    if(check_only) {
        log(usable?L"检测通过：现有驱动接口可打开；安装器内嵌文件和签名正常。":L"部署包检查通过，但设备尚不可用；请不带 --check 参数运行安装。");
        return usable?success:probe_error;
    }
    bool needs_restart=false;
    if(usable)log(L"已有兼容驱动可用，跳过驱动安装，不重复创建设备。");
    else {
        if(before.size()>1)fail(device_error,L"发现多个旧版 ToDesk 设备实例，停止自动修改。\n请在设备管理器确认重复/隐藏实例后处理，详情见日志。");
        if(!before.empty()) {
            const Node& n=before.front();
            if(!n.present)fail(device_error,L"存在离线/残留旧版设备实例："+n.id+L"。\n请先重启；仍失败时在设备管理器显示隐藏设备，确认并处理该残留实例后重试。");
            if(n.problem==CM_PROB_DISABLED)fail(device_error,L"旧版设备被禁用："+n.id+L"。请在设备管理器启用后重试。");
            if(n.problem==CM_PROB_NEED_RESTART)needs_restart=true;
            else {
                DWORD code=run_tool(deployment/L"driver"/L"devcon.exe",
                    L"update "+quote((deployment/L"driver"/L"TodeskVhid.inf").wstring())+L" "+quote(hardware_id),L"devcon-update.log");
                if(code>1)fail(install_error,L"修复已有驱动失败，devcon 退出码 "+std::to_wstring(code)+L"。\n查看 devcon-update.log 和 setupapi-tail.log；可能由签名、系统策略或版本冲突导致。");
                needs_restart=code==1;
            }
        } else {
            // Serialize all invocations and recheck immediately before creating a node.
            if(!legacy_nodes().empty())fail(busy_error,L"设备状态已变化，请关闭其他安装程序后重试。");
            DWORD code=run_tool(deployment/L"driver"/L"devcon.exe",
                L"install "+quote((deployment/L"driver"/L"TodeskVhid.inf").wstring())+L" "+quote(hardware_id),L"devcon-install.log");
            auto after=legacy_nodes();record_nodes(before,after);
            if(code>1)fail(install_error,L"驱动安装失败，devcon 退出码 "+std::to_wstring(code)+L"。\n"
                L"设备可能已创建但未正常启动；保留记录以便诊断，重试不会主动重复创建设备。\n查看 devcon-install.log、device-receipt.txt 和 setupapi-tail.log。");
            needs_restart=code==1;
        }
        if(!fs::exists(deployment/L"device-receipt.txt"))record_nodes(before,legacy_nodes());
        log(L"等待 HID 控制接口就绪（最多 20 秒）……");
        for(int attempt=0;attempt<40;++attempt) {
            if(probe(false)){usable=true;break;}
            Sleep(500);
        }
        auto after=legacy_nodes();
        for(const auto& n:after)if(n.problem==CM_PROB_NEED_RESTART)needs_restart=true;
    }
    if(!fs::exists(deployment/L"device-receipt.txt"))record_nodes(before,legacy_nodes());
    installed_instructions();
    if(!usable && !needs_restart) {
        probe();
        fail(probe_error,L"文件已部署，但驱动接口仍无法打开。\n请查看设备问题码/安装日志，重启后用 mouse_test.exe --probe 重试。\n"
            L"系统策略、签名限制或与现有 ToDesk 的冲突不能通过重复安装解决；此程序不会自动关闭安全保护。");
    }
    if(usable) {
        // Verify the actual deployed executable and its adjacent DLL, not only this setup's core.
        DWORD code=run_tool(deployment/L"app"/L"x64"/L"mouse_test.exe",L"--probe",L"probe.log",30000);
        if(code!=0)fail(probe_error,L"驱动接口检测通过，但部署后的测试程序连接失败，退出码 "+std::to_wstring(code)+L"；查看 probe.log。");
        log(L"PASS：部署后的 EXE + DLL 成功连接驱动，未发送任何鼠标输入。");
    }
    create_shortcut();
    return needs_restart?restart:success;
}
}

int wmain(int argc,wchar_t** argv) {
    SetConsoleOutputCP(CP_UTF8);
    bool check_only=false;
    for(int i=1;i<argc;++i) {
        if(wcscmp(argv[i],L"--check")==0)check_only=true;
        else if(wcscmp(argv[i],L"--quiet")==0)quiet=true;
        else if(wcscmp(argv[i],L"--help")==0) {
            log(L"ToDeskMouseSetup.exe [--check] [--quiet]\n默认：请求管理员权限并离线安装。--check：只释放文件/校验/检测，不修改驱动。--quiet：不弹结果对话框，仍可能出现 UAC。");return 0;
        } else {log(L"未知参数。使用 --help。");return 64;}
    }
    if(!check_only && !elevated()) {
        wchar_t path[32768]{};GetModuleFileNameW(nullptr,path,32768);
        SHELLEXECUTEINFOW info{};info.cbSize=sizeof(info);info.fMask=SEE_MASK_NOCLOSEPROCESS;
        info.lpVerb=L"runas";info.lpFile=path;info.lpParameters=quiet?L"--quiet":L"";info.nShow=SW_SHOWNORMAL;
        if(!ShellExecuteExW(&info)) {
            DWORD error=GetLastError();
            std::wstring message=error==ERROR_CANCELLED?L"已取消管理员授权，没有安装驱动。":L"无法请求管理员权限："+windows_error(error);
            log(message);if(!quiet)MessageBoxW(nullptr,message.c_str(),title,MB_OK|MB_ICONWARNING);return access_error;
        }
        Handle process(info.hProcess);WaitForSingleObject(process.h,INFINITE);DWORD code=access_error;GetExitCodeProcess(process.h,&code);return static_cast<int>(code);
    }
    int result=install_error;
    std::wstring message;
    try {
        Handle mutex(CreateMutexW(nullptr,FALSE,L"Global\\ToDeskMouseOfflineInstaller-v1"));
        if(!mutex.h)fail(busy_error,L"无法取得安装互斥锁，可能有其他用户正在运行安装器。");
        DWORD lock=WaitForSingleObject(mutex.h,0);
        if(lock!=WAIT_OBJECT_0 && lock!=WAIT_ABANDONED)fail(busy_error,L"已有安装/检测任务在运行，请等待完成。");
        struct Unlock{HANDLE h;~Unlock(){ReleaseMutex(h);}} unlock{mutex.h};
        start_log(check_only);
        result=execute(check_only);
        message=result==restart?L"驱动要求重启：文件已部署，但请重启电脑后再运行测试程序。未自动重启。":
            result==success?(check_only?L"检测通过，没有安装或修改驱动。":L"安装完成，已验证测试程序可连接驱动。"):
            L"驱动包校验通过，但当前设备尚不可用。请运行安装器执行安装。";
    } catch(const Failure& e){result=e.code;message=e.message;}
      catch(const std::exception& e){result=access_error;message=L"文件/系统操作异常，检查目录权限、磁盘和安全软件。";if(log_file)std::fprintf(log_file,"exception: %s\n",e.what());}
      catch(...){result=install_error;message=L"出现未预期错误，查看日志后重试。";}
    if(result!=success && result!=restart && !deployment.empty())diagnostic_logs();
    log(L"结果码："+std::to_wstring(result)+L"\n"+message);
    if(!log_path.empty())message+=L"\n\n日志："+log_path.wstring();
    if(!check_only && (result==success || result==restart))message+=L"\n测试程序："+(deployment/L"app"/L"x64"/L"mouse_test.exe").wstring();
    if(log_file){std::fclose(log_file);log_file=nullptr;}
    if(!quiet)MessageBoxW(nullptr,message.c_str(),title,MB_OK|(result==success?MB_ICONINFORMATION:MB_ICONWARNING));
    return result;
}
