from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
files = [
    ('TodeskVhid.dll', 'driver/TodeskVhid.dll'),
    ('TodeskVhid.inf', 'driver/TodeskVhid.inf'),
    ('todeskvhid.cat', 'driver/todeskvhid.cat'),
    ('devcon.exe', 'driver/devcon.exe'),
    ('x64/todesk_mouse.dll', 'app/x64/todesk_mouse.dll'),
    ('x64/mouse_test.exe', 'app/x64/mouse_test.exe'),
    ('x86/todesk_mouse.dll', 'app/x86/todesk_mouse.dll'),
    ('x86/mouse_test.exe', 'app/x86/mouse_test.exe'),
]
header = '#pragma once\nstruct Payload { int id; const wchar_t* path; const char* sha256; };\nstatic constexpr Payload payloads[] = {\n'
rc = '#include <windows.h>\n1 RT_MANIFEST "installer.manifest"\n'
for ident, (src, target) in enumerate(files, 101):
    data = (root / 'payload' / src).read_bytes()
    header += f'    {{{ident}, L"{target}", "{hashlib.sha256(data).hexdigest()}"}},\n'
    rc += f'{ident} RCDATA "payload/{src}"\n'
header += '};\n'
(root / 'payloads.h').write_text(header, encoding='utf-8')
(root / 'installer.rc').write_text(rc, encoding='utf-8')
print(f'Embedded {len(files)} files, SHA256 pinned.')
