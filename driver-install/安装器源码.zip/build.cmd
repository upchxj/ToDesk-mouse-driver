@echo off
setlocal
cd /d "%~dp0"
call "D:\VisualStdio\VC\Auxiliary\Build\vcvarsall.bat" amd64 >nul
if errorlevel 1 exit /b 1
rc /nologo /fo installer.res installer.rc
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /O2 /W4 /WX /utf-8 /MT /DTD_MOUSE_STATIC installer.cpp todesk_mouse.cpp installer.res /Fe:ToDeskMouseSetup.exe /link /MANIFEST:NO setupapi.lib cfgmgr32.lib hid.lib bcrypt.lib wintrust.lib crypt32.lib advapi32.lib shell32.lib ole32.lib user32.lib
exit /b %errorlevel%
