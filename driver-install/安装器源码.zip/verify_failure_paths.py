from pathlib import Path
import ctypes
import json
import subprocess

root = Path(__file__).resolve().parent
exe = root / 'ToDeskMouseSetup.exe'
results = []

def run(label, binary, args, expected):
    result = subprocess.run([str(binary), *args], capture_output=True, timeout=45)
    output = result.stdout.decode('utf-8', errors='replace')
    results.append({'test': label, 'exit_code': result.returncode, 'expected': expected, 'output': output})
    print(label, result.returncode, 'expected', expected)
    if result.returncode != expected:
        raise RuntimeError(output)

run('invalid_argument', exe, ['--not-an-option'], 64)
driver = (root / 'payload/TodeskVhid.dll').read_bytes()
data = bytearray(exe.read_bytes())
offset = data.find(driver)
assert offset >= 0 and data.find(driver, offset+1) < 0, 'Expected unique embedded driver'
data[offset+len(driver)-1] ^= 1
corrupt = root / 'CorruptPayload_TEST_ONLY.exe'
corrupt.write_bytes(data)
run('corrupted_embedded_driver', corrupt, ['--check','--quiet'], 12)

kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
kernel.CreateMutexW.restype = ctypes.c_void_p
kernel.ReleaseMutex.argtypes = [ctypes.c_void_p]
kernel.CloseHandle.argtypes = [ctypes.c_void_p]
handle = kernel.CreateMutexW(None, True, 'Global\\ToDeskMouseOfflineInstaller-v1')
assert handle, ctypes.get_last_error()
try:
    run('concurrent_installer', exe, ['--check','--quiet'], 17)
finally:
    kernel.ReleaseMutex(handle)
    kernel.CloseHandle(handle)

run('valid_package_after_failures', exe, ['--check','--quiet'], 0)
(root / 'failure-tests.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print('All failure-path tests passed.')
