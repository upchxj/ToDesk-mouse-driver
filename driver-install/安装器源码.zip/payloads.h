#pragma once
struct Payload { int id; const wchar_t* path; const char* sha256; };
static constexpr Payload payloads[] = {
    {101, L"driver/TodeskVhid.dll", "55adf9858ffbc0085d282487e3462ff318c5251082a58f5604872721a0244553"},
    {102, L"driver/TodeskVhid.inf", "f0fc1a36fb3a7e74eebb723d7d2d409a9675303e7f6863b5bb9d67df392d6621"},
    {103, L"driver/todeskvhid.cat", "0cb791ed0a41efacd965e052f372edb567c241cca18e53fe439ef7fbfc1ef667"},
    {104, L"driver/devcon.exe", "aca1bda08690dcca930254f96f9185c776671a85a58ffa1b59cf16017546f218"},
    {105, L"app/x64/todesk_mouse.dll", "68dca7cc943a9e77c7dc159c225fae3ceda5c70e10127a79a688567b52504a9c"},
    {106, L"app/x64/mouse_test.exe", "363bd524e9b7c4e0730c7fdd3b8c75cb06624b6618a9e618e564d0b5505bb3e4"},
    {107, L"app/x86/todesk_mouse.dll", "fade9ce7e0f1791259f5525d9f1fe8a9ce515c3db5159e72fc60c63bd80957de"},
    {108, L"app/x86/mouse_test.exe", "d0830acff2e46eef8147777c634c74df674d7fecb497378f5d9c8e0bdce2f3c7"},
};
